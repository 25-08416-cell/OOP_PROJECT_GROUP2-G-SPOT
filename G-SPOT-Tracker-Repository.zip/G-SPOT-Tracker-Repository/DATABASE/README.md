# DATABASE

This folder is reserved for database scripts, schemas, and migrations.

**Current implementation note:** The supplied G SPOT Tracker is a standalone browser application. Its current data storage uses the browser's `localStorage`; no external database schema or database server configuration was included in the supplied file.
